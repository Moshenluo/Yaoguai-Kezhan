# 妖怪客栈 · 水墨玩法篇 V3

16 秒，9:16，1080×1920，30fps，H.264，无声版本。沿用 V2 的文字推进、文字隧道、聚字和切镜节奏，将用户确认的三个核心玩法加入视觉叙事。

## 游戏信息依据

用户明确提供：**客栈经营接客、夜晚塔防、招募妖怪**。

本片的客栈、水墨妖怪来客、招募卡面与塔防路径均为宣传概念演绎。没有取得正式角色原画或游戏实机界面，不代表最终角色设计、实际布阵规则、攻击机制或游戏 UI。

## 观看

- `output/yaoguai-ink-v3.mp4`：完整视频，无音轨。
- `output/storyboard.jpg`：8 个关键画面。
- `output/shot-08.png`：片名封面。
- `index.html`：可交互播放器，支持播放、暂停、时间拖动与空格切换。

## 分镜

| 时间 | 内容 |
|---|---|
| 0–1.2s | 开门迎客：书法大字进入，客栈主视觉推进 |
| 1.2–3.2s | 四方来客：书法文字圈旋转，瓦檐客栈作为中心 |
| 3.2–5.2s | 经营客栈：接待来客、茶烟与灯笼 |
| 5.2–6.8s | 招募妖怪：三张概念妖怪卡面展开 |
| 6.8–8.4s | 伙伴集结：墨点聚成妖字 |
| 8.4–10s | 夜幕降临：客栈由日入夜 |
| 10–13.2s | 夜晚塔防：守护客栈的路径、伙伴布阵与攻击动线 |
| 13.2–16s | 妖怪客栈：片名与“经营接客 · 招募妖怪 · 夜晚塔防”落版 |

文案落点：**白日迎客，夜守灯火。**

## 美术与素材

- `assets/inn-ink.png`：本次生成的水墨设色客栈概念图。原始生成图保存在工作区 generated_images 中；分发包保留素材副本。
- 招募卡面和布阵头像取自同一张概念图中的三个妖怪来客，保持视觉一致；没有为它们编造官方姓名、职业或数值。
- 镜头运动、纸纹合成、日夜色调过渡、茶烟、书法文字与塔防概念动线均由 HTML Canvas 绘制。
- 书法字体：Ma Shan Zheng（马善政），来源为 Google Fonts 官方仓库 `ofl/mashanzheng`，SIL OFL 授权，见 `assets/MaShanZheng-OFL.txt`。正文：Noto Serif CJK SC 子集，授权见 `assets/FONT-LICENSE.txt`。
- 用户上传的参考录屏只用于分析运动方式，没有包含在交付包中。

## 修改和重新导出

`film.js` 中的 `scenes`、`cuts`、`defense()` 定义镜头和时间。`renderAt(seconds)` 是确定性渲染入口。

```bash
cd /workspace/yaoguai-pv-ink
node render.cjs --stills
node render.cjs
```

其他机器需要 Node.js、FFmpeg 和 Chromium，在目录执行 `npm install`，用 `CHROMIUM_PATH` 指定 Chrome/Chromium 程序后运行 `npm run render`。视频采用 Chromium 逐帧截图 → FFmpeg 编码，本版为 **480 帧 / 16 秒**。

直接打开 `index.html` 或运行 `python -m http.server 8080` 通过本地服务观看。字体已做子集，增加文案中的新字时需要重新制作子集或使用完整字体。

音乐将在用户提供文件后按重音、停顿、高潮与结尾重新对齐。目前没有生成或添加新音乐。
