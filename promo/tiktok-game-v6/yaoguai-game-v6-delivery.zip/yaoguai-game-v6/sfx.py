"""Original synthesized trailer sound effects; intentionally no background music or voice."""
import numpy as np,wave
from pathlib import Path
SR=48000;D=30;rng=np.random.default_rng(561)
mix=np.zeros((SR*D,2))
def add(x,start,pan=0):
 i=round(start*SR)
 if i<0:return
 n=min(len(x),len(mix)-i)
 if n>0:
  mix[i:i+n,0]+=x[:n]*np.sqrt((1-pan)/2);mix[i:i+n,1]+=x[:n]*np.sqrt((1+pan)/2)
def whoosh(start,length=.32,amp=.12,pan=0):
 t=np.arange(int(length*SR))/SR;n=rng.normal(0,1,len(t));n=np.convolve(n,np.ones(21)/21,'same');add(n*np.sin(np.pi*t/length)**1.7*amp,start,pan)
def chime(start,f=1100,amp=.055):
 t=np.arange(int(SR*.7))/SR;s=(np.sin(2*np.pi*f*t)+.25*np.sin(2*np.pi*f*2.73*t))*np.exp(-t*12)*(1-np.exp(-t*260));add(s*amp,start)
def thud(start,amp=.14):
 t=np.arange(int(SR*.3))/SR;s=np.sin(2*np.pi*(60*t+3*(1-np.exp(-t*24))))*np.exp(-t*18);add(s*amp,start)
def tap(start,amp=.07):
 t=np.arange(int(SR*.1))/SR;add((np.sin(2*np.pi*690*t)+.4*np.sin(2*np.pi*1110*t))*np.exp(-t*70)*amp,start)
whoosh(0,.35,.1);chime(.2,880,.07)
for start in [1.8,3,4.2,5.4,6.6,7.5,8.4,9.3,10.2,12,13.2,18,19.2,20.4,21.6,24,26.4]:whoosh(max(0,start-.17),.29,.14)
for start in [3.65,3.8,3.95]:chime(start,1450,.05)
thud(4.5,.1);tap(5.5,.1)
for start in [6.8,7.7,8.6,9.5]:chime(start,950,.065)
whoosh(11.2,.75,.2);thud(12.25,.11);thud(13.2,.14)
for i in range(8):
 hit=13.2+1.3+i*.38;whoosh(hit-.42,.32,.07,[-.5,.5,0][i%3]);tap(hit,.075);chime(hit,910+i*65,.023)
thud(18.05,.18);thud(18.6,.22)
for start in [19.53,19.65,19.77]:whoosh(start,.27,.16,.4);tap(start+.3,.09)
chime(20.7,660,.085);chime(20.9,880,.07);chime(21.1,1174,.045)
for i in range(7):
 hit=21.6+.65+i*.22;whoosh(hit-.4,.3,.06,[-.5,.5,0][i%3]);tap(hit,.06)
chime(23.72,880,.09);chime(23.87,1174,.065)
whoosh(26.4,.45,.16);thud(26.5,.1);chime(26.9,660,.065);chime(27.04,880,.04)
fade=np.minimum(np.arange(len(mix))/(SR*.005),1)*np.minimum((len(mix)-np.arange(len(mix)))/(SR*.25),1)
mix=np.tanh(mix*1.7)*fade[:,None]
with wave.open(str(Path(__file__).parent/'assets/sfx.wav'),'wb') as w:w.setnchannels(2);w.setsampwidth(2);w.setframerate(SR);w.writeframes((mix*32767).astype('<i2').tobytes())
print('30 seconds: original SFX only; peak',round(float(np.max(np.abs(mix))),4))
