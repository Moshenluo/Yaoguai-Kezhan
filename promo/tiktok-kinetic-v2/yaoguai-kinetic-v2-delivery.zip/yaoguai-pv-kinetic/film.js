// All graphics and camera poses are sampled from an absolute timeline.
const c=document.querySelector('canvas').getContext('2d'),W=1080,H=1920;
const PAPER='#f3eedf',INK='#19211e',RED='#e24e32',GOLD='#efc84b';
const sat=x=>Math.min(1,Math.max(0,x)),lerp=(a,b,x)=>a+(b-a)*x;
const out=x=>1-(1-sat(x))**4,io=x=>{x=sat(x);return x*x*(3-2*x)},back=x=>{x=sat(x);return 1+2.7*(x-1)**3+1.7*(x-1)**2};
function bg(col){c.fillStyle=col;c.fillRect(0,0,W,H)}
function rect(x,y,w,h,col){c.fillStyle=col;c.fillRect(x,y,w,h)}
function line(x,y,a,b,col=INK,w=2){c.beginPath();c.moveTo(x,y);c.lineTo(a,b);c.strokeStyle=col;c.lineWidth=w;c.stroke()}
function dot(x,y,r,col){c.beginPath();c.arc(x,y,r,0,Math.PI*2);c.fillStyle=col;c.fill()}
function tx(s,x,y,size,col=INK,o={}){c.save();c.translate(x,y);c.rotate(o.r||0);c.scale(o.sx??o.s??1,o.sy??o.s??1);c.globalAlpha*=o.a??1;c.textAlign='center';c.textBaseline='middle';c.font=`${size}px ${o.serif?'DisplaySerif':'Heavy'}`;c.fillStyle=col;if(o.stroke){c.strokeStyle=col;c.lineWidth=o.stroke;c.strokeText(s,0,0)}else c.fillText(s,0,0);c.restore()}
function cam(x,y,z,r,fn){c.save();c.translate(540,900);c.rotate(r);c.scale(z,z);c.translate(-x,-y);fn();c.restore()}
function small(s,x,y,col=INK){tx(s,x,y,22,col)}
function meta(t,col=INK){}
function rays(x,y,t,col){for(let i=0;i<12;i++){let a=i*Math.PI/6+t*.3,r=240+Math.sin(t*3+i)*8;line(x+Math.cos(a)*r,y+Math.sin(a)*r,x+Math.cos(a)*(r+28),y+Math.sin(a)*(r+28),col,5)}}
function smile(x,y,r,col,t){dot(x,y,r,col);dot(x-r*.29,y-r*.12,r*.055,INK);dot(x+r*.29,y-r*.12,r*.055,INK);c.beginPath();c.arc(x,y,r*.44,.16,Math.PI-.16);c.lineWidth=r*.04;c.strokeStyle=INK;c.stroke();c.save();c.translate(x,y);c.rotate(Math.sin(t*6)*.07);tx('欢 迎',0,-r*.55,r*.13,INK);c.restore()}
let points=[];
function pointGlyph(){const a=document.createElement('canvas');a.width=700;a.height=700;const d=a.getContext('2d');d.font='650px Heavy';d.textAlign='center';d.textBaseline='middle';d.fillText('妖',350,335);const p=d.getImageData(0,0,700,700).data;for(let y=0;y<700;y+=10)for(let x=0;x<700;x+=10)if(p[(y*700+x)*4+3]>100)points.push({x:x-350,y:y-350,a:(x*17+y*13)%628/100,r:600+(x*7+y*11)%900,k:(x+y)%7});}
function tunnel(u){bg(RED);const p=io(u/2.0),rot=-.45+u*.72,zoom=1+u*.65;cam(0,0,zoom,rot,()=>{for(let j=6;j>=0;j--){let radius=145+j*126;for(let k=0;k<12;k++){let a=k*Math.PI/6+j*.09;tx(k%2?'光临':'欢迎',Math.sin(a)*radius,Math.cos(a)*radius,37+j*14,PAPER,{r:-a+Math.PI/2,a:1-j*.055})}}rect(-100,-100,200,200,PAPER);tx('客栈',0,0,61,INK)});if(u>1.55){c.save();c.globalAlpha=io((u-1.55)/.45);bg(PAPER);c.restore()}}
const scenes=[
// 0–1.2: type enters along opposing trajectories; letter becomes the camera target.
function(u,t){bg(PAPER);let z=1+io((u-.82)/.38)*5;cam(500+io((u-.82)/.38)*110,860,z,-.025*Math.sin(u*8),()=>{tx('客',290,770,365,INK,{sx:.75+.25*out(u/.22),sy:1.2-.2*out(u/.22),r:(1-out(u/.3))*(-.3)});tx('官',710,1060-(out((u-.12)/.25))*180,365,RED,{r:(1-out((u-.12)/.3))*.4});tx('来啦！',510,1180,94,INK,{s:back((u-.37)/.4)});small('有 客 到 ——',500,470,INK);rays(500,930,u,RED)});meta(t)},
// 1.2–3.2: rotating dimensional typography tunnel.
function(u,t){tunnel(u);meta(t,u>1.6?INK:PAPER)},
// 3.2–5.2: glyph assembles out of orbital particles, then becomes solid type.
function(u,t){bg(PAPER);let settle=out(u/1.05),explode=io((u-1.65)/.35);const scale=1+explode*3;c.save();c.translate(500,945);c.scale(scale,scale);for(let p of points){let a=p.a+u*1.8;let x=lerp(Math.cos(a)*p.r,p.x,settle),y=lerp(Math.sin(a)*p.r,p.y,settle);dot(x,y,3.2+settle*.7,p.k===0?RED:INK)}c.restore();small('来的客人',500,425,INK);tx('有点特别',500,1450,87,RED,{s:out((u-.6)/.4)});meta(t)},
// 5.2–6.8: typographic size hierarchy and directional motion.
function(u,t){bg(INK);const q=out(u/.36),turn=io((u-1.24)/.36);cam(500,920,1+turn*2.5,turn*-.3,()=>{tx('有点',500,495,110,PAPER,{a:q});tx('妖',500,970,730,RED,{s:.08+.92*back(u/.46),serif:true});small('Y A O  /  好 奇 心 满 格',500,1510,PAPER)});meta(t,PAPER)},
// 6.8–8.4: staggered characters bounce with overshoot and elastic motion.
function(u,t){bg(GOLD);cam(500,920,1+.06*Math.sin(u*4),-.04+u*.05,()=>{['有','点','闹'].forEach((s,i)=>{let q=back((u-i*.12)/.35);tx(s,500+Math.sin(u*7+i)*12,(430+i*330)+(1-q)*420,i===2?380:235,i===2?RED:INK,{r:Math.sin(u*9+i)*.05,s:q})});for(let i=0;i<6;i++){let a=i*Math.PI/3+u;tx('!',500+Math.cos(a)*440,920+Math.sin(a)*660,70,RED,{r:a,s:.6+io(u/.4)*.4})}});meta(t)},
// 8.4–10: type folds out of a rotating carousel, with one longer reading beat.
function(u,t){bg(PAPER);let q=out(u/.6);cam(500,930,lerp(.55,1,q),lerp(-Math.PI/2,0,q),()=>{tx('更多的是',500,505,110,INK);tx('人间',500,835,269,INK,{serif:true});tx('烟火',500,1160,269,RED,{serif:true});line(208,1360,792,1360,INK,5)});meta(t)},
// 10–11.6: smile turns into the circular aperture of the next scene.
function(u,t){bg(RED);let r=180+io((u-.85)/.75)*1500;smile(500,950,r,GOLD,u);if(u<1){['吃','好','喝','好'].forEach((s,i)=>{let a=-Math.PI*.8+i*.53+u*.17;tx(s,500+Math.cos(a)*340,960+Math.sin(a)*340,90,PAPER,{r:a+Math.PI/2})})}small('把日子，过得有滋有味。',500,1460,INK);meta(t,PAPER)},
// 11.6–13.2: giant type runs on a slanted conveyor; central row resolves.
function(u,t){bg(GOLD);cam(500,920,1,-.12*(1-io((u-.75)/.65)),()=>{for(let row=-2;row<=2;row++){let y=920+row*260;let shift=(1-io((u-.65)/.75))*(row%2?-1:1)*(u*500+350);for(let col=-1;col<=1;col++)tx('客官里面请',500+shift+col*1160,y,155,row===0?INK:RED,{a:row===0?1:.2})}});meta(t)},
// 13.2–16: title pieces lock into place, resolving the moving type into a wordmark.
function(u,t){bg(PAPER);let q=io(u/.65);for(let j=0;j<5;j++){c.save();c.globalAlpha=(1-q)*.15;tx('妖怪客栈',500+(j-2)*100*(1-q),900+(j-2)*170,230,RED,{r:(1-q)*(j-2)*.2});c.restore()}['妖','怪','客','栈'].forEach((s,i)=>{let e=out((u-i*.09)/.6);let x=342+(i%2)*315,y=716+Math.floor(i/2)*325;tx(s,x+(1-e)*(i%2?650:-650),y+(1-e)*(i<2?-400:400),290,i===1?RED:INK,{r:(1-e)*(i%2?.7:-.7),serif:true})});line(195,1270,805,1270,RED,3);tx('客官，里面请！',500,1390,74,INK,{a:out((u-.65)/.4)});small('来来往往，都是故事。',500,1510,RED);meta(t)}
];
const cuts=[0,1.2,3.2,5.2,6.8,8.4,10,11.6,13.2,16];
window.renderAt=t=>{t=Math.max(0,Math.min(16,t));let k=0;while(k<8&&t>=cuts[k+1])k++;c.setTransform(1,0,0,1,0,0);c.globalAlpha=1;scenes[k](t-cuts[k],t);return {scene:k,time:t}};
let playing=false,offset=0,started=0;const seek=document.querySelector('#seek'),button=document.querySelector('#play');
function display(t){renderAt(t);seek.value=t;document.querySelector('#clock').textContent=`00:${String(Math.floor(t)).padStart(2,'0')} / 00:16`}
function toggle(){if(playing){offset=Math.min(16,(performance.now()-started)/1000);playing=false;button.textContent='继续'}else{if(offset>=16)offset=0;started=performance.now()-offset*1000;playing=true;button.textContent='暂停';requestAnimationFrame(tick)}}
function tick(){if(!playing)return;let t=Math.min(16,(performance.now()-started)/1000);display(t);if(t===16){playing=false;offset=16;button.textContent='重播'}else requestAnimationFrame(tick)}
button.onclick=toggle;seek.oninput=()=>{offset=+seek.value;started=performance.now()-offset*1000;display(offset)};document.addEventListener('keydown',e=>{if(e.code==='Space'&&e.target.tagName!=='INPUT'){e.preventDefault();toggle()}});if(new URLSearchParams(location.search).has('export'))document.body.classList.add('export');
window.ready=Promise.all([document.fonts.load('100px Heavy'),document.fonts.load('100px DisplaySerif')]).then(()=>{pointGlyph();display(0)});
