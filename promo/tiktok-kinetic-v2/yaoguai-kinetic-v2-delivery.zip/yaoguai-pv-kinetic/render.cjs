let playwright;try{playwright=require(process.env.PLAYWRIGHT_MODULE||'playwright')}catch{playwright=require('/workspace/Yaoguai-Kezhan/node_modules/playwright')}
const {chromium}=playwright;
const {spawn}=require('node:child_process');
const {once}=require('node:events');
const path=require('node:path');
const fs=require('node:fs');
const http=require('node:http');
async function main(){
 const root=__dirname;const fps=30;const duration=16;
 const server=http.createServer((req,res)=>{const name=decodeURIComponent(new URL(req.url,'http://localhost').pathname);const file=path.resolve(root,'.'+(name==='/'?'/index.html':name));if(!file.startsWith(root+path.sep)){res.writeHead(403);res.end();return;}const mime={'.html':'text/html','.js':'text/javascript','.otf':'font/otf','.wav':'audio/wav'};fs.readFile(file,(e,b)=>{res.writeHead(e?404:200,{'Content-Type':mime[path.extname(file)]||'application/octet-stream'});res.end(e?'Not found':b)})});
 await new Promise(r=>server.listen(0,'127.0.0.1',r));
 const browser=await chromium.launch({executablePath:process.env.CHROMIUM_PATH||'/usr/bin/chromium',headless:true,args:['--allow-file-access-from-files']});
 try{
 const page=await browser.newPage({viewport:{width:1080,height:1920},deviceScaleFactor:1});
 page.on('pageerror',e=>{console.error(e);process.exitCode=1});
 await page.goto(`http://127.0.0.1:${server.address().port}/?export`);await page.evaluate(()=>window.ready);
 const out=path.join(root,'output');fs.mkdirSync(out,{recursive:true});
 if(process.argv.includes('--stills')){for(const [i,t] of [.65,2.1,4.6,6.1,7.9,9.6,10.5,12.7,15].entries()){await page.evaluate(t=>renderAt(t),t);await page.screenshot({path:path.join(out,`shot-${String(i+1).padStart(2,'0')}.png`)});}console.log('9 review stills rendered');return;}
 const ff=spawn('ffmpeg',['-y','-hide_banner','-loglevel','warning','-f','image2pipe','-vcodec','mjpeg','-framerate',String(fps),'-i','pipe:0','-map','0:v','-c:v','libx264','-preset','fast','-crf','18','-pix_fmt','yuv420p','-threads','4','-an','-t',String(duration),'-movflags','+faststart',path.join(out,'yaoguai-kinetic-v2.mp4')],{stdio:['pipe','inherit','inherit']});
 let ffError;ff.on('error',e=>{ffError=e});ff.stdin.on('error',e=>{ffError=e});const finished=once(ff,'close');
 for(let n=0;n<fps*duration;n++){if(ffError)throw ffError;await page.evaluate(t=>renderAt(t),n/fps);const shot=await page.screenshot({type:'jpeg',quality:96});if(!ff.stdin.write(shot))await once(ff.stdin,'drain');if(n%150===0)console.log(`Rendered ${n}/${fps*duration} frames`)}
 ff.stdin.end();const [code]=await finished;if(code!==0)throw new Error('ffmpeg exited '+code);console.log('Export complete');
 }finally{await browser.close();server.close()}
}
main().catch(e=>{console.error(e);process.exit(1)});
