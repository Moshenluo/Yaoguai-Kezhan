"""Original synthesized trailer sound effects; intentionally no background music or voice."""
import numpy as np,wave
from pathlib import Path
SR=48000;D=30;rng=np.random.default_rng(561)
mix=np.zeros((SR*D,2))
def add(x,start,pan=0):
 i=round(start*SR)
 if i<0:return
 n=min(len(x),len(mix)-i)
 if n>0:
  mix[i:i+n,0]+=x[:n]*np.sqrt((1-pan)/2);mix[i:i+n,1]+=x[:n]*np.sqrt((1+pan)/2)
def whoosh(start,length=.32,amp=.12,pan=0):
 t=np.arange(int(length*SR))/SR;n=rng.normal(0,1,len(t));n=np.convolve(n,np.ones(21)/21,'same');add(n*np.sin(np.pi*t/length)**1.7*amp,start,pan)
def chime(start,f=1100,amp=.055):
 t=np.arange(int(SR*.7))/SR;s=(np.sin(2*np.pi*f*t)+.25*np.sin(2*np.pi*f*2.73*t))*np.exp(-t*12)*(1-np.exp(-t*260));add(s*amp,start)
def thud(start,amp=.14):
 t=np.arange(int(SR*.3))/SR;s=np.sin(2*np.pi*(60*t+3*(1-np.exp(-t*24))))*np.exp(-t*18);add(s*amp,start)
def tap(start,amp=.07):
 t=np.arange(int(SR*.1))/SR;add((np.sin(2*np.pi*690*t)+.4*np.sin(2*np.pi*1110*t))*np.exp(-t*70)*amp,start)
whoosh(0,.4,.15);chime(.12,830)
for mark in [1.8,4.8,5.4,6,9.2,10.4,12.2,16.6,19.6,22.6,26]:whoosh(max(0,mark-.2),.35,.13)
for start in [4.86,5.46]:chime(start,1400,.065)
for start in [6.15,6.48,6.8]:tap(start,.11);whoosh(start,.18,.09)
whoosh(10.4,1.2,.13);thud(12.2,.15)
for i in range(6):
 hit=12.2+1.4+i*.45;whoosh(hit-.4,.3,.07,[-.5,.5,0][i%3]);tap(hit,.06);chime(hit,930+i*80,.03)
thud(16.6,.2);whoosh(16.6,.65,.2);chime(17,660,.08)
for i in range(8):
 hit=19.6+1+i*.26;whoosh(hit-.4,.3,.065,[-.5,.5,0][i%3]);tap(hit,.05);chime(hit,950+i*70,.026)
chime(22.2,880,.08);chime(22.38,1174,.06)
whoosh(26,.5,.13);thud(26.1,.1);chime(26.4,660,.065);chime(26.54,880,.04)
fade=np.minimum(np.arange(len(mix))/(SR*.005),1)*np.minimum((len(mix)-np.arange(len(mix)))/(SR*.25),1)
mix=np.tanh(mix*1.7)*fade[:,None]
with wave.open(str(Path(__file__).parent/'assets/sfx.wav'),'wb') as w:w.setnchannels(2);w.setsampwidth(2);w.setframerate(SR);w.writeframes((mix*32767).astype('<i2').tobytes())
print('30 seconds: original SFX only; peak',round(float(np.max(np.abs(mix))),4))
