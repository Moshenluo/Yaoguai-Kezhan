"""Build a fully offline, double-clickable HTML player from the editable source."""
import base64,json,re
from pathlib import Path
ROOT=Path(__file__).parent
def uri(name,mime):
    return f'data:{mime};base64,'+base64.b64encode((ROOT/'assets'/name).read_bytes()).decode('ascii')
html=(ROOT/'index.html').read_text()
for name,mime in [('brush.ttf','font/ttf'),('serif.otf','font/otf'),('sfx.wav','audio/wav')]:
    html=html.replace('assets/'+name,uri(name,mime))
images={p.name:uri(p.name,'image/png') for p in sorted((ROOT/'assets').glob('*.png'))}
js=(ROOT/'film.js').read_text().replace("im.src='assets/'+name","im.src=embeddedImages[name]")
script='const embeddedImages='+json.dumps(images)+';\n'+js
html=html.replace('<script src="film.js"></script>','<script>'+script+'</script>')
(ROOT/'preview-standalone.html').write_text(html)
print('Offline HTML:',len(html.encode()),'bytes')
