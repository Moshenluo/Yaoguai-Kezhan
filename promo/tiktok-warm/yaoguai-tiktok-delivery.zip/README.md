# 妖怪客栈 · 客官，里面请！

20 秒竖屏文字概念 PV，1080 × 1920，30 fps，H.264 + AAC，原创 150 BPM 轻快配乐。

## 交付文件

- `output/yaoguai-kezhan-vertical.mp4`：适合竖屏上传的带声成片。
- `index.html`：交互播放器，可播放、暂停、拖动及静音；空格切换播放。
- `output/storyboard.jpg`：八段分镜总览。
- `output/shot-08.png`：片名竖版封面。

直接打开 HTML，或运行 `python -m http.server 8080` 后通过本地服务访问。播放需要点击按钮，不自动出声。页面无外部资源请求。

## 内容与节奏

| 时间 | 文案 |
|---|---|
| 0–2.4s | 开了家客栈 |
| 2.4–4.8s | 来的客人都有点特别 |
| 4.8–7.2s | 灯笼一挂，热闹开场 |
| 7.2–9.6s | 热汤上桌 |
| 9.6–12s | 茶香刚好，慢慢聊 |
| 12–14.4s | 来来 → 往往 → 都是故事 |
| 14.4–16.8s | 客官，里面请！ |
| 16.8–20s | 妖怪客栈 / 客官，里面请！ |

暖米色、朱红、暖黄与青绿，文字弹跳、图形摇摆和节拍快切。主要文字位于画面中上部，给平台底部和右侧 UI 留出空间；发布时仍应通过平台预览确认其实际遮挡情况。

## 修改和导出

`film.js` 的 `shots` 定义八段场景；`renderAt(seconds)` 以绝对时间生成确定画面。每个片段前 2.4 秒，最后片段 3.2 秒。图形均由 Canvas 绘制。

当前环境执行：

```bash
cd /workspace/yaoguai-pv-vertical
node render.cjs --stills
node render.cjs
```

其他机器需安装 Node.js、FFmpeg 和 Chromium，在工程目录执行 `npm install`，通过环境变量 `CHROMIUM_PATH` 指定 Chrome/Chromium 可执行文件路径，然后 `npm run render`。渲染器临时启动本地 HTTP 服务，使用 Playwright 截帧，FFmpeg 编码，完成后关闭浏览器和服务。

`score.py` 用 Python + NumPy 合成拨弦、木质打击与鼓点，未采样外部音乐。`assets/score.wav` 已包含在工程内，除非修改配乐，不需要重新生成。

中文字体已做子集，修改文案时如果引入新字，请重新制作字体子集或替换为完整字体。字体来自 Noto Serif/Sans CJK SC，授权见 `assets/FONT-LICENSE.txt`。

本片依据用户确认的“热闹、有趣、温暖”方向制作。当前未取得游戏角色、实机画面及完整设定，建筑、茶碗、灯笼均是原创概念图形，不代表已确认的游戏美术或玩法。源仓库和此前横版交付未改动。没有执行 TikTok 上传或其他对外发布。
