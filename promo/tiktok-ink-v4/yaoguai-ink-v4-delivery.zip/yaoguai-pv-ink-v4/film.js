// Deterministic ink-wash film; user-confirmed mechanics: inn management, recruitment, night tower defense.
const c=document.getElementById('film').getContext('2d'),W=1080,H=1920;
const PAPER='#eee3cd',INK='#26352f',RED='#a74430',GOLD='#c7a766',NIGHT='#142d32',JADE='#527367';
const sat=x=>Math.max(0,Math.min(1,x)),mix=(a,b,t)=>a+(b-a)*t,out=x=>1-(1-sat(x))**4,io=x=>{x=sat(x);return x*x*(3-2*x)},back=x=>{x=sat(x);return 1+2.7*(x-1)**3+1.7*(x-1)**2};
let artImage=new Image(),paperTexture,inkGlyph=[],blots=[],grain;
function box(x,y,w,h,col,r=0){c.fillStyle=col;c.beginPath();c.roundRect(x,y,w,h,r);c.fill()}
function line(x,y,a,b,col=INK,w=2){c.strokeStyle=col;c.lineWidth=w;c.lineCap='round';c.beginPath();c.moveTo(x,y);c.lineTo(a,b);c.stroke()}
function dot(x,y,r,col){c.beginPath();c.arc(x,y,r,0,Math.PI*2);c.fillStyle=col;c.fill()}
function tx(s,x,y,size,col=INK,o={}){c.save();c.translate(x,y);c.rotate(o.r||0);c.scale(o.sx??o.s??1,o.sy??o.s??1);c.globalAlpha*=o.a??1;c.textAlign='center';c.textBaseline='middle';c.font=`${size}px ${o.serif?'TextSerif':'Brush'}`;c.fillStyle=col;c.fillText(s,0,0);c.restore()}
function cam(x,y,z,r,fn){c.save();c.translate(540,925);c.rotate(r);c.scale(z,z);c.translate(-x,-y);fn();c.restore()}
function small(s,x,y,col=INK,size=26){tx(s,x,y,size,col,{serif:true})}
function paper(){c.fillStyle=paperTexture;c.fillRect(0,0,W,H)}
function noise(){c.save();c.globalAlpha=.22;c.fillStyle=grain;c.fillRect(0,0,W,H);c.restore()}
function painting(z=1,x=540,y=960){c.save();c.translate(x,y);c.scale(z,z);c.drawImage(artImage,-540,-960,1080,1920);c.restore()}
function veil(top=0,bottom=1000,opacity=.94){const g=c.createLinearGradient(0,top,0,bottom);g.addColorStop(0,`rgba(238,227,205,${opacity})`);g.addColorStop(.7,`rgba(238,227,205,${opacity*.66})`);g.addColorStop(1,'rgba(238,227,205,0)');c.fillStyle=g;c.fillRect(0,top,1080,bottom-top)}
function seal(s,x,y,size=95,col=RED){c.save();c.translate(x,y);c.rotate(-.07);c.fillStyle=col;c.beginPath();c.moveTo(-size*.5,-size*.5);c.lineTo(size*.48,-size*.46);c.lineTo(size*.5,size*.49);c.lineTo(-size*.48,size*.5);c.closePath();c.fill();c.strokeStyle=PAPER;c.lineWidth=2;c.strokeRect(-size*.41,-size*.4,size*.81,size*.81);if(s.length<=2){[...s].forEach((ch,i)=>tx(ch,0,(i-(s.length-1)/2)*size*.37,size*.43,PAPER))}else{[...s].forEach((ch,i)=>tx(ch,(i%2-.5)*size*.4,(Math.floor(i/2)-.5)*size*.4,size*.4,PAPER))}c.restore()}
function dryArc(x,y,r,t,col=INK,w=8,start=.1,end=5.9){c.save();c.translate(x,y);c.rotate(t);for(let j=0;j<7;j++){c.globalAlpha=(j===0?.64:.13);c.beginPath();for(let i=0;i<=90;i++){const a=start+(end-start)*i/90,rr=r+Math.sin(a*7+j)*4+j-3;let xx=Math.cos(a)*rr,yy=Math.sin(a)*rr;i?c.lineTo(xx,yy):c.moveTo(xx,yy)}c.lineWidth=w+j%3;c.strokeStyle=col;c.stroke()}c.restore()}
function brushLine(x,y,a,b,width,col){c.save();c.strokeStyle=col;c.lineCap='butt';for(let i=0;i<13;i++){c.globalAlpha=.08+(i===6?.38:0);c.lineWidth=width/12*(i%3+1);let d=(i-6)*width/14;c.beginPath();c.moveTo(x+d*.2,y+d);c.quadraticCurveTo((x+a)/2,(y+b)/2+Math.sin(i)*8,a-d*.2,b+d*.55);c.stroke()}c.restore()}
function inkBloom(progress,col=INK){if(progress<=0)return;c.save();const r=out(progress)*1700;for(let i=0;i<38;i++){let a=i*2.399,x=540+Math.cos(a)*(120+i*11),y=940+Math.sin(a)*(160+i*19);c.globalAlpha=.065;dot(x,y,r*(.4+(i%4)*.045),col)}c.restore()}
function steam(x,y,t,s=1,col=PAPER){c.save();c.strokeStyle=col;c.lineWidth=2.5;c.globalAlpha=.64;for(let i=0;i<3;i++){c.beginPath();for(let j=0;j<55;j++){let px=x+(i-1)*24*s+Math.sin(j*.1+t*2+i)*14*s,py=y-j*4*s;j?c.lineTo(px,py):c.moveTo(px,py)}c.stroke()}c.restore()}
function leaves(t,col=GOLD){for(let i=0;i<10;i++){let x=(87+i*229+t*(10+i%4))%1150-40,y=(210+i*163+t*24)%1900;c.save();c.translate(x,y);c.rotate(i+t*.5);c.globalAlpha=.55;c.fillStyle=col;c.beginPath();c.ellipse(0,0,3+i%3,12+i%5,0,0,Math.PI*2);c.fill();c.restore()}}
// Portrait windows use the same concept artwork; no imported game character claims.
const guests=[{sx:.185,sy:.745,sw:.22,sh:.165},{sx:.405,sy:.741,sw:.236,sh:.17},{sx:.64,sy:.751,sw:.225,sh:.165}];
function guestImage(i,x,y,w,h){let p=guests[i],iw=artImage.width,ih=artImage.height;c.drawImage(artImage,p.sx*iw,p.sy*ih,p.sw*iw,p.sh*ih,x,y,w,h)}
function portrait(i,x,y,r,t=0){c.save();c.beginPath();c.arc(x,y,r,0,Math.PI*2);c.clip();guestImage(i,x-r,y-r,r*2,r*2);c.restore();dryArc(x,y,r+4,t*.03,GOLD,2)}
function guestCard(i,x,y,s,angle,t){c.save();c.translate(x,y);c.rotate(angle);c.scale(s,s);c.shadowColor='#152b2528';c.shadowBlur=18;c.shadowOffsetY=15;box(-170,-255,340,510,PAPER,5);c.shadowColor='transparent';c.strokeStyle=GOLD;c.lineWidth=2;c.strokeRect(-156,-240,312,480);c.save();c.beginPath();c.rect(-146,-212,292,335);c.clip();guestImage(i,-146,-212,292,335);c.restore();brushLine(-105,149,105,149,5,RED);tx('妖怪来客',0,188,47,INK);seal('结缘',115,-220,64);c.restore()}
function nightScene(t,amount=1,z=1.03){paper();painting(z,540+Math.sin(t*.3)*10,970);c.save();c.globalCompositeOperation='multiply';c.globalAlpha=amount;box(0,0,W,H,'#4a6c78');c.restore();const g=c.createLinearGradient(0,0,0,H);g.addColorStop(0,`rgba(17,41,48,${.8*amount})`);g.addColorStop(.53,`rgba(17,41,48,${.2*amount})`);g.addColorStop(1,`rgba(17,41,48,${.68*amount})`);c.fillStyle=g;c.fillRect(0,0,W,H);c.save();c.globalAlpha=amount;dot(842,214,50,PAPER);dot(862,196,49,NIGHT);for(let p of [[554,1170],[795,1160],[260,1200],[615,887]]){const glow=c.createRadialGradient(p[0],p[1],0,p[0],p[1],100);glow.addColorStop(0,'#ffd78c50');glow.addColorStop(1,'#ffd78c00');c.fillStyle=glow;c.fillRect(p[0]-100,p[1]-100,200,200)}c.restore()}
// V4 editorial pass: five narrative beats, shared actor positions and readable mobile typography.
const GUARDS=[[245,1085],[790,1205],[255,1410]];
const CUTS=[0,3.2,6.6,7.6,12.8,16];
const sceneNames=['经营迎客','招募伙伴','入夜转折','塔防守店','片名落版'];
function topWash(end=940,strength=.98){veil(0,end,strength)}
function heading(label,subtitle,appear=1,dark=false){c.save();c.globalAlpha=appear;tx(label,500,338,176,dark?PAPER:INK);if(subtitle)small(subtitle,500,538,dark?GOLD:RED,54);c.restore()}
function imageCircle(i,x,y,r){c.save();c.beginPath();c.arc(x,y,r,0,Math.PI*2);c.clip();guestImage(i,x-r,y-r,r*2,r*2);c.restore();dryArc(x,y,r+3,0,GOLD,2)}
function joinActor(i,x,y,scale,angle,morph=0){
 c.save();c.translate(x,y);c.rotate(angle*(1-morph));let w=mix(370*scale,190,morph),h=mix(570*scale,190,morph),r=mix(6,95,morph),pad=mix(21*scale,7,morph),label=mix(112*scale,0,morph);
 c.shadowColor='#1a342a30';c.shadowBlur=20*(1-morph);c.shadowOffsetY=14*(1-morph);box(-w/2,-h/2,w,h,PAPER,r);c.shadowColor='transparent';
 c.save();c.beginPath();c.roundRect(-w/2+pad,-h/2+pad,w-pad*2,h-pad*2-label,Math.max(0,r-pad));c.clip();guestImage(i,-w/2+pad,-h/2+pad,w-pad*2,h-pad*2-label);c.restore();
 if(morph<.94){c.save();c.globalAlpha=1-morph;brushLine(-w*.29,h*.31,w*.29,h*.31,7,RED);tx('妖怪伙伴',0,h*.39,52*scale,INK);c.restore()}
 c.strokeStyle=GOLD;c.lineWidth=2;c.beginPath();c.roundRect(-w/2,-h/2,w,h,r);c.stroke();c.restore();
}
function roster(u,t,forcedMorph=null){
 const morph=forcedMorph??io((u-2.74)/.66),poses=[[226,1110,.8,-.1],[500,1000,1.25,.01],[779,1130,.8,.1]];
 for(const i of [0,2,1]){let [x,y,s,a]=poses[i],e=out((u-.17*i)/.42);x=mix(x+(1-e)*(i-1)*700,GUARDS[i][0],morph);y=mix(y+(1-e)*270,GUARDS[i][1],morph);joinActor(i,x,y,s*e,a,morph)}
}
function terrainPath(k){return {x:500+Math.sin(k*Math.PI*2)*183,y:1590-k*770}}
function innTarget(){
 c.save();c.beginPath();c.arc(500,815,122,0,Math.PI*2);c.clip();c.drawImage(artImage,105,520,720,760,378,693,244,244);c.restore();dryArc(500,815,128,0,GOLD,4);
 c.save();c.globalAlpha=.95;box(436,872,128,72,PAPER,5);tx('客栈',500,908,50,INK);c.restore();
}
function boardBackdrop(t){
 nightScene(t,1,1.025);const g=c.createLinearGradient(0,520,0,1100);g.addColorStop(0,'#142d3200');g.addColorStop(.38,'#142d32c7');g.addColorStop(1,'#142d32fc');c.fillStyle=g;c.fillRect(0,520,W,1400);
 // Sparse ink-contour terrain gives the tactical view a clear central playing area.
 for(let j=0;j<3;j++){c.save();c.globalAlpha=.07;c.strokeStyle=GOLD;c.lineWidth=2;c.beginPath();for(let k=0;k<60;k++){let y=850+k*15,x=120+j*20+Math.sin(k*.13+j)*27;k?c.lineTo(x,y):c.moveTo(x,y)}c.stroke();c.restore()}
 c.save();c.strokeStyle='#b3a37c';c.lineWidth=4;c.setLineDash([7,16]);c.beginPath();for(let j=0;j<=90;j++){let p=terrainPath(j/90);j?c.lineTo(p.x,p.y):c.moveTo(p.x,p.y)}c.stroke();c.restore();innTarget();
 for(let i=0;i<3;i++){const [x,y]=GUARDS[i];c.save();c.globalAlpha=.13;dryArc(x,y,162,0,GOLD,2);c.restore();imageCircle(i,x,y,91);dryArc(x,y,101,-t*.13,GOLD,3)}
}
function battle(u,t){
 c.save();let cameraScale=1+.038*Math.sin(Math.min(u/5.2,1)*Math.PI);c.translate(500,1120);c.scale(cameraScale,cameraScale);c.translate(-500,-1120);boardBackdrop(t);
 const hits=[1.65,2.12,2.6,3.08,3.57,4.18],goals=[.39,.68,.52,.76,.42,.64];
 for(let i=0;i<hits.length;i++){
  const hit=hits[i],spawn=.05+i*.32,goal=goals[i],age=u-hit,enemyP=sat((u-spawn)/(hit-spawn)),p=terrainPath(goal*enemyP),target=terrainPath(goal),[gx,gy]=GUARDS[i%3];
  if(u>=spawn&&u<hit){c.save();c.globalAlpha=out((u-spawn)/.15);dot(p.x,p.y,25,'#a74430');dryArc(p.x,p.y,28,0,GOLD,2);tx('影',p.x,p.y,29,PAPER);c.restore()}
  const launch=hit-.42;
  if(u>=launch&&u<hit){let f=(u-launch)/.42,tail=Math.max(0,f-.22);let px=mix(gx,target.x,f),py=mix(gy,target.y,f);c.save();c.shadowColor='#f5d69f';c.shadowBlur=17;line(mix(gx,target.x,tail),mix(gy,target.y,tail),px,py,GOLD,7);dot(px,py,8,PAPER);c.restore();dryArc(gx,gy,108+(u-launch)*16,0,GOLD,5)}
  if(age>=0&&age<.38){const f=age/.38;c.save();c.globalAlpha=1-f;dryArc(target.x,target.y,18+f*67,f*.2,GOLD,5);for(let j=0;j<8;j++){let a=j*Math.PI/4;dot(target.x+Math.cos(a)*(14+f*65),target.y+Math.sin(a)*(14+f*65),3.5,GOLD)}c.restore()}
 }
 if(u>4.38){const q=out((u-4.38)/.42);c.save();c.globalAlpha=q*.8;dryArc(500,815,145+q*14,0,GOLD,5);c.restore()}
 c.restore();heading('夜晚塔防','布阵守店，共护灯火',1,true);
}
const scenes=[
 // 0–3.2: one clear promise and one scene, with a brief ink-circle transition at the end.
 function(u,t){paper();painting(1.09-u*.025,548-u*3,968);topWash(945);small('经营客栈',500,236,RED,50);tx('白天',365,432,200,INK,{r:-.015,s:out(u/.24)});tx('迎客',585,655,255,RED,{r:.015,s:back((u-.1)/.37)});steam(673,1330,t,.76);leaves(t);if(u>2.72){let q=io((u-2.72)/.48);c.save();c.globalAlpha=q;paper();c.restore();const z=1+q*3.5;c.save();c.translate(500,975);c.scale(z,z);c.rotate(q*.28);for(let i=0;i<3;i++)dryArc(0,0,164+i*102,q*.1,i===0?INK:RED,3);c.save();c.beginPath();c.arc(0,0,154,0,Math.PI*2);c.clip();guestImage(1,-154,-154,308,308);c.restore();c.restore()}},
 // 3.2–6.6: large, readable recruitment cards transform into the same units used in battle.
 function(u,t){paper();c.save();c.globalAlpha=.11;painting(1.1);c.restore();topWash(1700,.96);const m=io((u-2.74)/.66);heading('招募妖怪','集结守店伙伴',1-m);roster(u,t);},
 // 6.6–7.6: lighting transition and tactical board arrive without introducing another message.
 function(u,t){boardBackdrop(t);tx('入夜',500,389,242,PAPER,{s:.86+.14*out(u/.35)});small('同一间客栈，另一场热闹。',500,586,GOLD,46);},
 // 7.6–12.8: more than five seconds for placement, incoming wave, attacks and a visual resolution.
 function(u,t){battle(u,t)},
 // 12.8–16: stop competing for attention; keep the title legible for more than two seconds.
 function(u,t){paper();painting(1.035-u*.006,540,1000);const wash=c.createLinearGradient(0,0,0,1370);wash.addColorStop(0,'#eee3cdfa');wash.addColorStop(.77,'#eee3cdfa');wash.addColorStop(1,'#eee3cd00');c.fillStyle=wash;c.fillRect(0,0,W,1370);['妖','怪','客','栈'].forEach((s,i)=>{let e=out((u-i*.065)/.43),x=355+(i%2)*298,y=372+Math.floor(i/2)*282;tx(s,x+(1-e)*(i%2?260:-260),y,269,i===1?RED:INK,{r:(1-e)*(i%2?.12:-.12),a:e})});small('白日迎客，夜守灯火。',500,873,INK,57);brushLine(260,951,740,947,7,RED);small('经营 · 招募 · 塔防',500,1038,RED,49);leaves(t)}
];
function mixColor(a,b,t){const x=parseInt(a.slice(1),16),y=parseInt(b.slice(1),16);let v=[16,8,0].map(s=>Math.round(mix((x>>s)&255,(y>>s)&255,t)));return `rgb(${v.join(',')})`}
window.renderAt=t=>{t=Math.max(0,Math.min(16,t));let k=0;while(k<4&&t>=CUTS[k+1])k++;c.setTransform(1,0,0,1,0,0);c.globalAlpha=1;scenes[k](t-CUTS[k],t);noise();return {time:t,scene:k,name:sceneNames[k]}};
function init(){const a=document.createElement('canvas');a.width=a.height=300;const d=a.getContext('2d');d.drawImage(artImage,350,15,160,160,0,0,300,300);paperTexture=c.createPattern(a,'repeat');const n=document.createElement('canvas');n.width=n.height=192;const nd=n.getContext('2d'),p=nd.createImageData(192,192);let seed=71;for(let i=0;i<p.data.length;i+=4){seed=(seed*1664525+1013904223)>>>0;p.data[i]=p.data[i+1]=p.data[i+2]=seed%255;p.data[i+3]=24}nd.putImageData(p,0,0);grain=c.createPattern(n,'repeat')}
let playing=false,offset=0,started=0;const seek=document.querySelector('#seek'),button=document.querySelector('#play');
function display(t){renderAt(t);seek.value=t;document.querySelector('#clock').textContent=`00:${String(Math.floor(t)).padStart(2,'0')} / 00:16`}
function toggle(){if(playing){offset=Math.min(16,(performance.now()-started)/1000);playing=false;button.textContent='继续'}else{if(offset>=16)offset=0;started=performance.now()-offset*1000;playing=true;button.textContent='暂停';requestAnimationFrame(tick)}}
function tick(){if(!playing)return;let t=Math.min(16,(performance.now()-started)/1000);display(t);if(t===16){playing=false;offset=16;button.textContent='重播'}else requestAnimationFrame(tick)}
button.onclick=toggle;seek.oninput=()=>{offset=+seek.value;started=performance.now()-offset*1000;display(offset)};document.addEventListener('keydown',e=>{if(e.code==='Space'&&e.target.tagName!=='INPUT'){e.preventDefault();toggle()}});if(new URLSearchParams(location.search).has('export'))document.body.classList.add('export');
const imageReady=new Promise((resolve,reject)=>{artImage.onload=resolve;artImage.onerror=()=>reject(Error('Concept art failed to load'));artImage.src='assets/inn-ink.png'});
window.ready=Promise.all([imageReady,document.fonts.load('100px Brush'),document.fonts.load('100px TextSerif')]).then(()=>{init();display(0)});
