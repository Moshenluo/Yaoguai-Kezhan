"""Generate an offline HTML player with embedded fonts, artwork, and original SFX."""
import base64,json
from pathlib import Path
ROOT=Path(__file__).parent
def uri(name,mime):return f'data:{mime};base64,'+base64.b64encode((ROOT/'assets'/name).read_bytes()).decode('ascii')
html=(ROOT/'index.html').read_text()
for name,mime in [('brush.ttf','font/ttf'),('serif.otf','font/otf'),('sfx.wav','audio/wav')]:html=html.replace('assets/'+name,uri(name,mime))
images={p.name:uri(p.name,'image/png' if p.suffix=='.png' else 'image/jpeg') for p in sorted((ROOT/'assets').iterdir()) if p.suffix in ['.png','.jpg']}
js=(ROOT/'film.js').read_text().replace("im.src='assets/'+file","im.src=embeddedImages[file]")
html=html.replace('<script src="film.js"></script>','<script>const embeddedImages='+json.dumps(images)+';\n'+js+'</script>')
(ROOT/'preview-standalone.html').write_text(html)
print('Offline player:',len(html.encode()),'bytes')
