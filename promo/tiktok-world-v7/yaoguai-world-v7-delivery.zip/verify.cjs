// Integration checks for the standalone player and final encoded MP4.
const fs=require('node:fs'),path=require('node:path'),http=require('node:http');
let pw;try{pw=require(process.env.PLAYWRIGHT_MODULE||'playwright')}catch{pw=require('/workspace/Yaoguai-Kezhan/node_modules/playwright')}
const root=__dirname,errors=[];
async function main(){
 const browser=await pw.chromium.launch({executablePath:process.env.CHROMIUM_PATH||'/usr/bin/chromium',headless:true});let server;
 try{
  let offline;if(process.argv.includes('--video-only'))offline=JSON.parse(fs.readFileSync(path.join(root,'output/offline-check.json'),'utf8')).offline;else{
  const ctx=await browser.newContext({offline:true,viewport:{width:390,height:900}}),page=await ctx.newPage(),requests=[];
  page.on('pageerror',e=>errors.push(e.message));page.on('request',r=>{if(/^https?:/.test(r.url()))requests.push(r.url())});
  await page.setContent(fs.readFileSync(path.join(root,'preview-standalone.html'),'utf8'),{waitUntil:'load'});await page.evaluate(()=>window.ready);
  offline=await page.evaluate(()=>({fonts:[document.fonts.check('100px Brush'),document.fonts.check('100px Book')],overflow:document.documentElement.scrollWidth>innerWidth,assets:Object.keys(images).length,canvasReadable:document.querySelector('canvas').toDataURL().length>10000}));
  await page.click('#play');await page.waitForTimeout(400);offline.played=await page.evaluate(()=>Number(document.querySelector('#seek').value)>.1);await page.click('#play');
  const cameras=await page.evaluate(()=>Array.from({length:901},(_,i)=>renderAt(i/30).camera));
  let maxCameraStep=0;for(let i=1;i<cameras.length;i++){const [x,y,z]=cameras[i],[px,py,pz]=cameras[i-1];if(![x,y,z].every(Number.isFinite)||x<1080/(2*z)-.01||x>1080-1080/(2*z)+.01||y<1920/(2*z)-.01||y>1920-1920/(2*z)+.01)throw Error('Camera exposed an edge');maxCameraStep=Math.max(maxCameraStep,Math.hypot(x-px,y-py))}
  offline.httpRequests=requests.length;offline.maxCameraWorldStep=maxCameraStep;
  if(errors.length||requests.length||offline.overflow||!offline.fonts.every(Boolean)||!offline.played||!offline.canvasReadable)throw Error('Standalone check failed');
  await ctx.close();}
  if(process.argv.includes('--offline-only')){fs.writeFileSync(path.join(root,'output/offline-check.json'),JSON.stringify({offline,errors},null,2));console.log(JSON.stringify({offline,errors}));return}
  const file=path.join(root,'output/yaoguai-world-v7.mp4'),stat=fs.statSync(file);
  server=http.createServer((req,res)=>{if(req.url==='/'){res.writeHead(200,{'Content-Type':'text/html'});res.end('<video muted controls width="390" src="/film.mp4"></video>');return}if(req.url!='/film.mp4'){res.writeHead(404);res.end();return}const m=/bytes=(\d+)-(\d*)/.exec(req.headers.range||'');if(m){const start=+m[1],end=m[2]?Math.min(+m[2],stat.size-1):stat.size-1;res.writeHead(206,{'Content-Type':'video/mp4','Content-Range':`bytes ${start}-${end}/${stat.size}`,'Accept-Ranges':'bytes','Content-Length':end-start+1});fs.createReadStream(file,{start,end}).pipe(res)}else{res.writeHead(200,{'Content-Type':'video/mp4','Content-Length':stat.size,'Accept-Ranges':'bytes'});fs.createReadStream(file).pipe(res)}});
  await new Promise(resolve=>server.listen(0,'127.0.0.1',resolve));const vp=await browser.newPage();await vp.goto(`http://127.0.0.1:${server.address().port}`);await vp.waitForFunction(()=>document.querySelector('video').readyState>=2);
  const video=await vp.evaluate(async()=>{const v=document.querySelector('video');v.currentTime=6.28;await new Promise(r=>v.addEventListener('seeked',r,{once:true}));await v.play();return {duration:v.duration,width:v.videoWidth,height:v.videoHeight,start:v.currentTime}});await vp.waitForTimeout(500);video.after=await vp.evaluate(()=>document.querySelector('video').currentTime);
  if(video.duration!==30||video.width!==1080||video.height!==1920||video.after<=video.start+.2)throw Error('Encoded video playback failed');
  fs.writeFileSync(path.join(root,'output/integration-check.json'),JSON.stringify({offline,video,errors},null,2));console.log(JSON.stringify({offline,video,errors}));
 }finally{if(server)server.close();await browser.close()}
}
main().catch(e=>{console.error(e);process.exit(1)});
