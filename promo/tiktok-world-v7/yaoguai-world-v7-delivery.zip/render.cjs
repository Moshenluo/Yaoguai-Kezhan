let playwright;try{playwright=require(process.env.PLAYWRIGHT_MODULE||'playwright')}catch{playwright=require('/workspace/Yaoguai-Kezhan/node_modules/playwright')}
const {chromium}=playwright;
const {spawn}=require('node:child_process');
const {once}=require('node:events');
const path=require('node:path');
const fs=require('node:fs');
const http=require('node:http');
async function main(){
 const root=__dirname,fps=30,duration=30,out=path.join(root,'output');fs.mkdirSync(out,{recursive:true});
 const server=http.createServer((req,res)=>{const name=decodeURIComponent(new URL(req.url,'http://localhost').pathname);const file=path.resolve(root,'.'+(name==='/'?'/index.html':name));if(!file.startsWith(root+path.sep)){res.writeHead(403);res.end();return}const mime={'.html':'text/html; charset=utf-8','.js':'text/javascript; charset=utf-8','.png':'image/png','.ttf':'font/ttf','.otf':'font/otf','.wav':'audio/wav'};fs.readFile(file,(e,b)=>{res.writeHead(e?404:200,{'Content-Type':mime[path.extname(file)]||'application/octet-stream'});res.end(e?'Not found':b)})});
 await new Promise(r=>server.listen(0,'127.0.0.1',r));
 let browser,ff,renderError;const errors=[];
 try{
 browser=await chromium.launch({executablePath:process.env.CHROMIUM_PATH||'/usr/bin/chromium',headless:true});
 const page=await browser.newPage({viewport:{width:1080,height:1920},deviceScaleFactor:1});
 page.on('pageerror',e=>errors.push(e.message));
 await page.goto(`http://127.0.0.1:${server.address().port}/?export`);await page.evaluate(()=>window.ready);
 if(process.argv.includes('--stills')){
   for(const [i,t] of [.8,1.7,3.5,4.8,5.85,6.3,7.5,8.45,10.4,12.3,14.3,16.8,18.8,19.8,21.8,23.4,28.4].entries()){await page.evaluate(t=>renderAt(t),t);await page.screenshot({path:path.join(out,`shot-${String(i+1).padStart(2,'0')}.png`)})}
   console.log('17 review stills rendered');
   await page.setViewportSize({width:390,height:900});await page.goto(`http://127.0.0.1:${server.address().port}/`);await page.evaluate(()=>window.ready);await page.evaluate(()=>{renderAt(9.85);document.querySelector('#seek').value=9.85});await page.screenshot({path:path.join(out,'phone-preview.png')});
   const before=await page.evaluate(()=>({fonts:[document.fonts.check('100px Brush'),document.fonts.check('100px Book')],overflow:document.documentElement.scrollWidth>innerWidth,sprites:Object.keys(sprites).length,audio:document.querySelector('audio').readyState}));
   await page.click('#play');await page.waitForTimeout(250);const playing=await page.evaluate(()=>document.querySelector('#play').textContent==='暂停'&&Number(document.querySelector('#seek').value)>0);await page.click('#play');
   await page.locator('#seek').fill('22.6');await page.locator('#seek').dispatchEvent('input');await page.click('#sound');const after=await page.evaluate(()=>({paused:document.querySelector('#play').textContent==='继续',seek:Number(document.querySelector('#seek').value),muted:document.querySelector('audio').muted}));
   for(const t of [0,1.8,5.4,6.6,10.2,12,13.2,18,19.2,20.4,21.6,24,26.4,30])await page.evaluate(t=>renderAt(t),t);
   const result={before,playing,after,errors};fs.writeFileSync(path.join(out,'browser-check.json'),JSON.stringify(result,null,2));console.log(JSON.stringify(result));if(errors.length||before.overflow||!before.fonts.every(Boolean)||!playing||!after.paused||after.seek!==22.6||!after.muted)throw Error('Browser check failed');return;
 }
 ff=spawn('ffmpeg',['-y','-hide_banner','-loglevel','warning','-f','image2pipe','-vcodec','mjpeg','-framerate',String(fps),'-i','pipe:0','-i',path.join(root,'assets/sfx.wav'),'-map','0:v','-map','1:a','-vf','scale=in_range=pc:out_range=tv:out_color_matrix=bt709,format=yuv420p','-color_range','tv','-colorspace','bt709','-color_primaries','bt709','-color_trc','bt709','-c:v','libx264','-preset','medium','-crf','20','-maxrate','8M','-bufsize','16M','-pix_fmt','yuv420p','-threads','4','-bsf:v','h264_metadata=colour_primaries=1:transfer_characteristics=1:matrix_coefficients=1:video_full_range_flag=0','-c:a','aac','-b:a','192k','-t',String(duration),'-movflags','+faststart',path.join(out,'yaoguai-world-v7.mp4')],{stdio:['pipe','inherit','inherit']});
 ff.on('error',e=>renderError=e);ff.stdin.on('error',e=>renderError=e);const finished=once(ff,'close');
 for(let n=0;n<fps*duration;n++){if(renderError)throw renderError;if(errors.length)throw Error(errors.join('\n'));await page.evaluate(t=>renderAt(t),n/fps);const shot=await page.screenshot({type:'jpeg',quality:96});if(!ff.stdin.write(shot))await once(ff.stdin,'drain');if(n%150===0)console.log(`Rendered ${n}/${fps*duration} frames`)}
 ff.stdin.end();const [code]=await finished;if(code!==0)throw Error('ffmpeg exited '+code);console.log('Export complete');
 }finally{if(ff&&ff.exitCode===null)ff.kill();if(browser)await browser.close();server.close()}
}
main().catch(e=>{console.error(e);process.exit(1)});
