# 妖怪客栈 · 灯火同归篇 V7

30 秒竖版宣传演出，1080×1920，30fps。含轻音效，背景音乐待配。非实机录屏。

本版改为同一座近景院落里的连续演出：迎客、端汤放碗、新伙计接手后厨、入夜就位、协力守门。镜头跟随动作；角色和背景共用镜头变换，按地面深度缩放，配合投影、接触阴影、昼夜调色及桌椅遮挡。新增狌狌端汤、俯身放碗两张动作差分。文字保留在开场、入职、守店和片名节点。

## 打开

直接使用成片 `yaoguai-world-v7.mp4`。离线预览：用 Chrome / Edge 打开 `preview-standalone.html` 后点击播放。所有图片、字体和音效已经内嵌，不依赖服务地址。GitHub 文件页请点击 Download raw file 下载；GitHub 不会把 HTML 当作网站运行。

## 编辑与导出

需要 Node.js、Playwright、Chromium、FFmpeg；重新合成音效另需 Python 3、NumPy。

```bash
npm install --ignore-scripts
CHROMIUM_PATH=/usr/bin/chromium node render.cjs --stills
CHROMIUM_PATH=/usr/bin/chromium node render.cjs
python3 build_preview.py
```

导出器自动启动临时本地静态服务、逐帧调用 `renderAt(t)`、将 900 帧送入 FFmpeg，完成后关闭浏览器和服务。系统 Chromium 可用时不必另下载浏览器。`PLAYWRIGHT_MODULE` 可指定已有 Playwright 安装。云环境默认复用 `/workspace/Yaoguai-Kezhan/node_modules/playwright`。

`film.js` 中 `paths` 控制走位，`poseTracks` 控制动作，`cameraKeys` 控制同一世界里的镜头。`tableMasks` / `frontMasks` 是与院落匹配的遮挡轮廓。`manifest.json` 和 `music-brief.md` 提供时间表与音乐对点。

## 素材来源

游戏资源来自 `Moshenluo/Yaoguai-Kezhan` 的 `feature/kyl-import-game` 分支，提交 `e9ae4ff31fdec9480a75635970e5aab77b2621b5`。原始角色、敌人和 UI 按字节保留；运行时只做合成。新院落昼夜底图、角色差分为参考原美术生成的宣传衍生图，详见 `provenance.json`。这是二维分层演出，包含姿势切换和程序形变，不是完整逐帧手绘角色动画。

字体使用 Ma Shan Zheng / Noto Serif CJK，许可文件在 assets 内。音效由 `sfx.py` 原创合成。
