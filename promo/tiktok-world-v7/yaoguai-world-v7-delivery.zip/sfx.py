"""Original synthesized trailer sound effects; intentionally no background music or voice."""
import numpy as np,wave
from pathlib import Path
SR=48000;D=30;rng=np.random.default_rng(561)
mix=np.zeros((SR*D,2))
def add(x,start,pan=0):
 i=round(start*SR)
 if i<0:return
 n=min(len(x),len(mix)-i)
 if n>0:
  mix[i:i+n,0]+=x[:n]*np.sqrt((1-pan)/2);mix[i:i+n,1]+=x[:n]*np.sqrt((1+pan)/2)
def whoosh(start,length=.32,amp=.12,pan=0):
 t=np.arange(int(length*SR))/SR;n=rng.normal(0,1,len(t));n=np.convolve(n,np.ones(21)/21,'same');add(n*np.sin(np.pi*t/length)**1.7*amp,start,pan)
def chime(start,f=1100,amp=.055):
 t=np.arange(int(SR*.7))/SR;s=(np.sin(2*np.pi*f*t)+.25*np.sin(2*np.pi*f*2.73*t))*np.exp(-t*12)*(1-np.exp(-t*260));add(s*amp,start)
def thud(start,amp=.14):
 t=np.arange(int(SR*.3))/SR;s=np.sin(2*np.pi*(60*t+3*(1-np.exp(-t*24))))*np.exp(-t*18);add(s*amp,start)
def tap(start,amp=.07):
 t=np.arange(int(SR*.1))/SR;add((np.sin(2*np.pi*690*t)+.4*np.sin(2*np.pi*1110*t))*np.exp(-t*70)*amp,start)
# SFX follow the visible actions in the uninterrupted courtyard.
for start in [0.4,.86,1.3,2.45,2.7,2.95,3.85,4.2,4.55,4.9,5.2,6.8,7.1,7.4,9.5,9.8,10.1]:tap(start,.014)
chime(3.48,1210,.025);tap(6.02,.045);chime(6.11,1670,.024)
chime(8.45,880,.044);chime(8.65,1100,.025)
whoosh(11.7,1.2,.06);chime(13.1,660,.03)
for start in [14.6,15.1,15.7,16.3,16.85,17.4,18.0]:thud(start,.018)
whoosh(18.24,.43,.11,-.45);thud(18.72,.18)
whoosh(19.27,.48,.10,.45);tap(19.75,.065);thud(19.75,.075)
chime(20.91,660,.055);chime(21.1,990,.032);whoosh(21.3,.4,.08);thud(21.7,.065)
chime(21.8,880,.04);chime(22.02,1174,.033)
whoosh(22.87,.48,.085,.35);tap(23.35,.06);thud(23.35,.07)
for start in [24.6,25.1,25.6]:tap(start,.012)
chime(26.0,660,.035);chime(26.3,880,.03);chime(26.62,1174,.025)
fade=np.minimum(np.arange(len(mix))/(SR*.005),1)*np.minimum((len(mix)-np.arange(len(mix)))/(SR*.25),1)
mix=np.tanh(mix*1.7)*fade[:,None]
with wave.open(str(Path(__file__).parent/'assets/sfx.wav'),'wb') as w:w.setnchannels(2);w.setsampwidth(2);w.setframerate(SR);w.writeframes((mix*32767).astype('<i2').tobytes())
print('30 seconds: original SFX only; peak',round(float(np.max(np.abs(mix))),4))
